# 세이투두 (SayToDo) - 구글 로그인 설정 가이드

## 🔐 구글 로그인 통합

세이투두는 구글 계정으로 간편하게 로그인할 수 있습니다. 별도의 회원가입 절차 없이 **구글 로그인만으로 자동 가입 및 로그인**이 처리됩니다!

---

## 📋 Firebase 및 구글 로그인 설정

### 1. Firebase Console 설정

1. **Firebase Console** 접속: https://console.firebase.google.com/
2. 프로젝트 선택 또는 새 프로젝트 생성
3. **Authentication** 메뉴 선택
4. **Sign-in method** 탭에서 **Google** 활성화

### 2. Android 앱 추가

1. Firebase Console → 프로젝트 설정
2. **Android 앱 추가** 클릭
3. **패키지 이름**: `com.saytodo` 입력
4. **SHA-1 인증서** 추가 (필수!)

#### SHA-1 인증서 생성 방법:

**개발용 키스토어:**
```bash
cd android
./gradlew signingReport
```

출력된 SHA-1 값을 복사하여 Firebase Console에 추가

**또는 직접 keytool 사용:**
```bash
# Windows
keytool -list -v -keystore "%USERPROFILE%\.android\debug.keystore" -alias androiddebugkey -storepass android -keypass android

# Mac/Linux
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

5. `google-services.json` 다운로드
6. `SayToDo/android/app/google-services.json`에 저장

### 3. Web Client ID 가져오기

1. Firebase Console → 프로젝트 설정 → 일반
2. **앱** 섹션에서 Web 앱 추가 (없으면 생성)
3. **Web 클라이언트 ID** 복사

**또는 Google Cloud Console에서:**
1. https://console.cloud.google.com/ 접속
2. API 및 서비스 → 사용자 인증 정보
3. OAuth 2.0 클라이언트 ID에서 **웹 클라이언트** 찾기
4. 클라이언트 ID 복사 (형식: `XXXXXX.apps.googleusercontent.com`)

### 4. 앱 코드 설정

`SayToDo/App.tsx` 파일 수정:
```typescript
// Firebase Web Client ID (실제 값으로 교체)
const GOOGLE_WEB_CLIENT_ID = 'YOUR_ACTUAL_WEB_CLIENT_ID.apps.googleusercontent.com';
```

**실제 Web Client ID로 교체해야 합니다!**

---

## 🔧 Android 빌드 설정

### build.gradle 확인

**android/build.gradle:**
```gradle
dependencies {
    classpath("com.android.tools.build:gradle")
    classpath("com.facebook.react:react-native-gradle-plugin")
    classpath("org.jetbrains.kotlin:kotlin-gradle-plugin")
    classpath("com.google.gms:google-services:4.4.0")  // ✅ 이미 추가됨
}
```

**android/app/build.gradle:**
```gradle
apply plugin: "com.android.application"
apply plugin: "org.jetbrains.kotlin.android"
apply plugin: "com.facebook.react"
apply plugin: "com.google.gms.google-services"  // ✅ 이미 추가됨
```

### AndroidManifest.xml 확인

`android/app/src/main/AndroidManifest.xml`에 이미 필요한 권한이 추가되어 있습니다:
- ✅ INTERNET
- ✅ POST_NOTIFICATIONS
- ✅ 기타 필요한 권한들

---

## 📱 앱 실행 및 테스트

### 1. 의존성 설치
```bash
cd SayToDo
npm install
```

### 2. Android 빌드
```bash
npm run android
```

### 3. Metro 번들러 실행
```bash
npm start
```

### 4. 로그인 테스트
1. 앱 실행
2. "Google 계정으로 시작하기" 버튼 클릭
3. 구글 계정 선택
4. 자동으로 가입/로그인 완료! ✅

---

## 🎯 구글 로그인 동작 방식

### 자동 가입/로그인 프로세스

```
사용자가 구글 로그인 버튼 클릭
         ↓
Google Sign-In SDK가 구글 계정 정보 가져오기
         ↓
백엔드 서버로 구글 정보 전송 (이메일, 이름, 프로필 사진)
         ↓
서버에서 이메일 확인
         ↓
├─ 기존 사용자: 로그인 처리
└─ 신규 사용자: 자동 가입 후 로그인
         ↓
JWT 토큰 발급 및 FCM 토큰 등록
         ↓
앱에 사용자 정보 저장 완료! 🎉
```

### 백엔드 API 엔드포인트

**POST /api/auth/google-login**
```json
{
  "email": "user@gmail.com",
  "name": "홍길동",
  "photoUrl": "https://...",
  "googleId": "1234567890"
}
```

**응답:**
```json
{
  "message": "자동 가입 및 로그인 성공",
  "user": {
    "id": "uuid",
    "email": "user@gmail.com",
    "nickname": "홍길동",
    "photoUrl": "https://..."
  },
  "token": "jwt-token",
  "isNewUser": true
}
```

---

## 🐛 트러블슈팅

### "DEVELOPER_ERROR" 또는 "10" 에러
- **원인**: SHA-1 인증서가 Firebase Console에 등록되지 않음
- **해결**: SHA-1 생성 후 Firebase Console에 추가

### Web Client ID 오류
- **원인**: 잘못된 Web Client ID 사용
- **해결**: Firebase Console에서 정확한 Web Client ID 확인

### 구글 로그인 화면이 나타나지 않음
- **원인**: Google Play Services 미설치 (에뮬레이터)
- **해결**: Play Services가 설치된 에뮬레이터 사용 또는 실제 기기 사용

### "Sign in action cancelled" 에러
- 사용자가 로그인을 취소한 경우 (정상)

---

## 📄 관련 파일

### React Native 앱
- `App.tsx` - 메인 앱 (구글 로그인 통합)
- `src/screens/LoginScreen.tsx` - 로그인 화면
- `src/services/googleAuth.ts` - 구글 인증 서비스
- `src/services/api.ts` - API 클라이언트

### 백엔드 서버
- `voip-server/routes/auth.js` - 구글 로그인 API
- `voip-server/database.js` - 사용자 테이블 (photo_url 추가)

---

## 🎉 완료!

이제 구글 계정만으로 세이투두를 사용할 수 있습니다!

별도의 회원가입, 비밀번호 설정 없이 **구글 로그인 한 번**으로 모든 준비 완료! 🚀
