#!/bin/bash
# APK 로컬 빌드 스크립트

echo "🚀 SayToDo APK 빌드 시작..."

# Android 디렉토리로 이동
cd android

# Gradle wrapper 실행 권한 부여
chmod +x gradlew

# APK 빌드
echo "📦 APK 빌드 중... (약 5-10분 소요)"
./gradlew assembleRelease --no-daemon

# 빌드 결과 확인
if [ -f "app/build/outputs/apk/release/app-release.apk" ]; then
    echo "✅ APK 빌드 완료!"
    echo "📱 APK 위치: app/build/outputs/apk/release/app-release.apk"
    
    # APK 파일 크기 확인
    ls -lh app/build/outputs/apk/release/app-release.apk
    
    # 상위 디렉토리로 복사
    cp app/build/outputs/apk/release/app-release.apk ../../SayToDo-v1.0.0.apk
    echo "📦 APK 복사 완료: ../../SayToDo-v1.0.0.apk"
else
    echo "❌ APK 빌드 실패"
    exit 1
fi
