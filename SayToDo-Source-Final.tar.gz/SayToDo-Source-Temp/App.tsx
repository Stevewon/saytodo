import React, { useEffect, useState } from 'react';
import {
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Alert,
  View,
  Text,
  ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import FCMService from './src/services/fcm';
import GoogleAuthService from './src/services/googleAuth';
import DeepLinkService from './src/services/deeplink';
import LoginScreen from './src/screens/LoginScreen';
import AppNavigator from './src/navigation/AppNavigator';
import { FCMAlertData } from './src/types';

// Firebase Web Client ID
const GOOGLE_WEB_CLIENT_ID = '1068989331005-3k2i2btovivbnquol72s1r8mu3kum5if.apps.googleusercontent.com';

function App(): React.JSX.Element {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [fcmInitialized, setFcmInitialized] = useState(false);
  const [loading, setLoading] = useState(true);
  const [pendingInviteCode, setPendingInviteCode] = useState<string | null>(null);

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    // 구글 로그인 설정
    GoogleAuthService.configure(GOOGLE_WEB_CLIENT_ID);

    // 딥링크 초기화
    DeepLinkService.initialize();
    DeepLinkService.addListener(handleDeepLink);

    // 로그인 상태 확인
    await checkLoginStatus();

    // FCM 초기화
    await initializeFCM();

    setLoading(false);
  };

  const checkLoginStatus = async () => {
    try {
      const token = await AsyncStorage.getItem('authToken');
      const userJson = await AsyncStorage.getItem('user');
      
      if (token && userJson) {
        const userData = JSON.parse(userJson);
        setUser(userData);
        setIsLoggedIn(true);
        console.log('User logged in:', userData.email);
      }
    } catch (error) {
      console.error('Check login status error:', error);
    }
  };

  const initializeFCM = async () => {
    try {
      const initialized = await FCMService.initialize(
        handleForegroundMessage,
        handleNotificationOpened
      );
      setFcmInitialized(initialized);
      console.log('FCM initialized:', initialized);
    } catch (error) {
      console.error('FCM initialization error:', error);
    }
  };

  const handleForegroundMessage = (data: FCMAlertData) => {
    console.log('Foreground alert received:', data);
    
    Alert.alert(
      `${data.senderName} - ${data.channelName}`,
      data.title,
      [
        {
          text: '거절',
          style: 'cancel',
          onPress: () => handleAlertResponse(data.alertId, 'rejected'),
        },
        {
          text: '수락',
          onPress: () => handleAlertResponse(data.alertId, 'accepted'),
        },
      ],
      { cancelable: false }
    );
  };

  const handleNotificationOpened = (data: FCMAlertData) => {
    console.log('App opened by notification:', data);
    // TODO: 알림 상세 화면으로 이동
  };

  const handleAlertResponse = async (alertId: string, response: 'accepted' | 'rejected') => {
    try {
      // TODO: API 호출 구현
      console.log(`Alert ${alertId} ${response}`);
      Alert.alert('응답 완료', `알림을 ${response === 'accepted' ? '수락' : '거절'}했습니다.`);
    } catch (error) {
      console.error('Alert response error:', error);
    }
  };

  const handleLoginSuccess = (userData: any, token: string) => {
    setUser(userData);
    setIsLoggedIn(true);
    console.log('Login success:', userData.email);

    // 로그인 후 대기 중인 초대 코드 처리
    if (pendingInviteCode) {
      Alert.alert(
        '채널 초대',
        '초대 링크로 채널에 가입하시겠습니까?',
        [
          {
            text: '취소',
            style: 'cancel',
            onPress: () => setPendingInviteCode(null),
          },
          {
            text: '가입하기',
            onPress: () => {
              // TODO: 자동 가입 처리
              setPendingInviteCode(null);
            },
          },
        ]
      );
    }
  };

  const handleDeepLink = (link: { inviteCode: string }) => {
    console.log('Deep link received:', link);
    
    if (!isLoggedIn) {
      // 로그인 안 된 상태면 대기
      setPendingInviteCode(link.inviteCode);
      Alert.alert(
        '로그인 필요',
        '채널에 가입하려면 먼저 로그인해주세요.'
      );
    } else {
      // 로그인 된 상태면 바로 처리
      Alert.alert(
        '채널 초대',
        `초대 코드: ${link.inviteCode}\n\n채널에 가입하시겠습니까?`,
        [
          {
            text: '취소',
            style: 'cancel',
          },
          {
            text: '가입하기',
            onPress: () => {
              // TODO: 자동 가입 처리 (AppNavigator로 전달)
            },
          },
        ]
      );
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4285F4" />
          <Text style={styles.loadingText}>로딩 중...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isLoggedIn) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#4285F4" />
      <AppNavigator />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#999',
  },
});

export default App;
