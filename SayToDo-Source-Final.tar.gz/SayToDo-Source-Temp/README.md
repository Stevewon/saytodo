# 세이투두 (SayToDo) 📞

전화벨처럼 울리는 할 일 알림 - React Native Android 앱

## 🎯 개요

세이투두는 채널 기반 긴급 알림 시스템입니다. 일반 메시지나 알림과 달리, **전화처럼 무조건 울리는** 방식으로 중요한 메시지를 전달합니다.

## ✨ 주요 기능

### 1. 채널 관리
- 채널 생성 및 멤버 초대
- 관리자/멤버 권한 관리
- 이메일 기반 멤버 추가

### 2. VoIP 스타일 알림
- **전화벨처럼 울리는 알림** (무음/진동 모드 우회)
- Full-screen intent로 화면 켜짐
- 수락/거절 버튼
- High priority FCM Push

### 3. 미디어 지원
- 🎤 **음성 메시지**: 녹음 파일 재생
- 🎬 **짧은 영상**: 직접 업로드 및 재생
- 📺 **긴 영상**: YouTube URL 링크

### 4. 실시간 응답
- 수락/거절/미응답 트래킹
- Socket.io 실시간 응답 알림
- 응답 통계 확인

## 🛠 기술 스택

- **React Native 0.83.1**
- **TypeScript**
- **Firebase Cloud Messaging (FCM)** - Push 알림
- **Socket.io Client** - 실시간 통신
- **Axios** - HTTP 클라이언트
- **AsyncStorage** - 로컬 저장소

## 📦 설치 및 실행

### 사전 요구사항

1. **Node.js** (v20 이상)
2. **React Native 개발 환경** 설정
   - [React Native 환경 설정 가이드](https://reactnative.dev/docs/environment-setup)
3. **Android Studio** 및 Android SDK
4. **Firebase 프로젝트** 생성

### Firebase 설정

1. Firebase Console에서 Android 앱 추가
2. 패키지 이름: `com.saytodo`
3. `google-services.json` 다운로드
4. 파일을 `android/app/` 디렉토리에 저장

### 의존성 설치

```bash
npm install

# iOS (선택사항)
cd ios && pod install && cd ..
```

### Android 빌드 및 실행

```bash
# 개발 모드
npm run android

# 또는 직접 빌드
cd android
./gradlew assembleDebug
cd ..
```

### Metro 번들러 실행

```bash
npm start
```

## 📱 앱 구조

```
SayToDo/
├── android/                    # Android 네이티브 코드
│   └── app/
│       ├── src/main/
│       │   ├── java/com/saytodo/
│       │   │   └── fcm/
│       │   │       └── FCMService.java  # 커스텀 FCM 서비스
│       │   └── AndroidManifest.xml
│       └── google-services.json        # Firebase 설정 (생성 필요)
├── src/
│   ├── components/             # UI 컴포넌트
│   ├── screens/                # 화면 컴포넌트
│   ├── services/               # 서비스 레이어
│   │   ├── api.ts             # API 클라이언트
│   │   └── fcm.ts             # FCM 서비스
│   ├── navigation/             # 네비게이션
│   ├── types/                  # TypeScript 타입 정의
│   └── utils/                  # 유틸리티
│       └── config.ts          # API 설정
├── App.tsx                     # 메인 앱 컴포넌트
└── index.js                    # 엔트리 포인트
```

## 🔧 환경 설정

### API 서버 URL 변경

`src/utils/config.ts` 파일에서 백엔드 서버 URL을 변경할 수 있습니다:

```typescript
export const API_CONFIG = {
  BASE_URL: 'YOUR_BACKEND_SERVER_URL',
  // ...
};
```

### Firebase 설정 확인

1. `android/app/google-services.json` 파일 존재 여부 확인
2. 패키지 이름이 `com.saytodo`와 일치하는지 확인
3. Firebase Console에서 FCM 활성화 확인

## 🚀 배포

### APK 빌드

```bash
cd android
./gradlew assembleRelease
```

빌드된 APK 위치:
```
android/app/build/outputs/apk/release/app-release.apk
```

### Play Store 배포

1. 서명 키 생성
2. `android/app/build.gradle`에 서명 설정 추가
3. Bundle 생성: `./gradlew bundleRelease`

## 🔔 FCM 알림 동작 방식

### 1. 앱 포그라운드
- FCM 메시지 수신
- Alert 다이얼로그 표시
- 수락/거절 버튼

### 2. 앱 백그라운드
- FCM High Priority Push 수신
- Full-screen 알림 표시 (화면 켜짐)
- 수락/거절 액션 버튼
- 전화벨 소리 및 진동

### 3. 앱 종료 상태
- FCM 메시지로 앱 재시작
- 알림 데이터로 특정 화면 열기

## 📝 API 엔드포인트

백엔드 서버: `https://3002-i831dov1p3qmbwxmdvsyx-5634da27.sandbox.novita.ai`

주요 엔드포인트:
- `POST /api/auth/register` - 회원가입
- `POST /api/auth/login` - 로그인
- `POST /api/auth/fcm-token` - FCM 토큰 등록
- `GET /api/channels/my-channels` - 내 채널 목록
- `POST /api/alerts/send` - 긴급 알림 발송
- `POST /api/alerts/respond` - 알림 응답

전체 API 문서: [voip-server/README.md](../voip-server/README.md)

## 🐛 트러블슈팅

### FCM 알림이 오지 않음
1. `google-services.json` 파일 확인
2. Firebase Console에서 FCM 활성화 확인
3. 앱 권한 확인 (알림, Full-screen intent)

### 빌드 오류
```bash
cd android
./gradlew clean
cd ..
npm start --reset-cache
```

### Metro 번들러 캐시 삭제
```bash
npm start --reset-cache
```

## 📋 TODO

- [ ] 로그인/회원가입 UI
- [ ] 채널 목록 화면
- [ ] 채널 상세 화면
- [ ] 알림 발송 화면
- [ ] 알림 히스토리
- [ ] 미디어 재생 (음성/영상)
- [ ] YouTube 영상 재생
- [ ] 프로필 설정
- [ ] 푸시 알림 설정

## 🔐 권한

앱이 요청하는 권한:
- `INTERNET` - 네트워크 통신
- `POST_NOTIFICATIONS` - 알림 표시
- `VIBRATE` - 진동
- `USE_FULL_SCREEN_INTENT` - 전체 화면 알림
- `WAKE_LOCK` - 화면 켜기
- `FOREGROUND_SERVICE` - 포그라운드 서비스

## 📄 라이선스

MIT

---

**세이투두 - 놓치지 않는 알림 시스템** 📞
