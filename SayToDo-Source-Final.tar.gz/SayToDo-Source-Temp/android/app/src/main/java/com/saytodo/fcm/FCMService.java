package com.saytodo.fcm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.saytodo.MainActivity;
import com.saytodo.R;
import android.util.Log;

public class FCMService extends FirebaseMessagingService {
    private static final String TAG = "FCMService";
    private static final String CHANNEL_ID = "voip_alerts";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "FCM Message received from: " + remoteMessage.getFrom());

        // Data payload 확인
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
            
            String type = remoteMessage.getData().get("type");
            if ("voip_alert".equals(type)) {
                handleVoipAlert(remoteMessage.getData());
            }
        }

        // Notification payload 확인
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
            showNotification(
                remoteMessage.getNotification().getTitle(),
                remoteMessage.getNotification().getBody()
            );
        }
    }

    private void handleVoipAlert(java.util.Map<String, String> data) {
        String alertId = data.get("alertId");
        String channelName = data.get("channelName");
        String title = data.get("title");
        String message = data.get("message");
        String senderName = data.get("senderName");

        Log.d(TAG, "VoIP Alert: " + title + " from " + senderName);

        // 전화벨 스타일 알림 표시
        showVoipNotification(alertId, channelName, title, message, senderName, data);
    }

    private void showVoipNotification(String alertId, String channelName, 
                                       String title, String message, 
                                       String senderName, java.util.Map<String, String> data) {
        NotificationManager notificationManager = 
            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Android 8.0 이상: Notification Channel 생성
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "긴급 알림",
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("전화벨처럼 울리는 긴급 알림");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationManager.createNotificationChannel(channel);
        }

        // Intent: 앱 열기
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("alertId", alertId);
        intent.putExtra("type", "voip_alert");
        
        // Data 전달
        for (java.util.Map.Entry<String, String> entry : data.entrySet()) {
            intent.putExtra(entry.getKey(), entry.getValue());
        }

        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 
            alertId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // 벨소리
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);

        // Notification 생성
        NotificationCompat.Builder notificationBuilder =
            new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(senderName + " - " + channelName)
                .setContentText(title)
                .setStyle(new NotificationCompat.BigTextStyle()
                    .bigText(title + "\n\n" + message))
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setFullScreenIntent(pendingIntent, true)
                .setContentIntent(pendingIntent)
                .setVibrate(new long[]{0, 1000, 500, 1000})
                .addAction(R.drawable.ic_launcher_foreground, "수락", 
                    createActionIntent(alertId, "accepted"))
                .addAction(R.drawable.ic_launcher_foreground, "거절", 
                    createActionIntent(alertId, "rejected"));

        notificationManager.notify(alertId.hashCode(), notificationBuilder.build());
    }

    private PendingIntent createActionIntent(String alertId, String action) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("alertId", alertId);
        intent.putExtra("action", action);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        
        return PendingIntent.getActivity(
            this,
            (alertId + action).hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void showNotification(String title, String body) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        );

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        
        NotificationCompat.Builder notificationBuilder =
            new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(0, notificationBuilder.build());
    }

    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);
        // 여기서 토큰을 서버에 전송해야 합니다
        // React Native 측으로 이벤트 전송 가능
    }
}
