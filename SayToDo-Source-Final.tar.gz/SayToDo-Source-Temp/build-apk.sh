#!/bin/bash

# 색상 정의
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  📱 SayToDo APK 빌드 시작${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# 현재 디렉토리 확인
CURRENT_DIR=$(pwd)
echo -e "${YELLOW}📂 현재 디렉토리: $CURRENT_DIR${NC}"
echo ""

# Android 디렉토리 확인
if [ ! -d "android" ]; then
    echo -e "${RED}❌ android 디렉토리를 찾을 수 없습니다!${NC}"
    echo -e "${YELLOW}💡 SayToDo 프로젝트 루트에서 실행해주세요.${NC}"
    exit 1
fi

echo -e "${GREEN}[1/5] Firebase 설정 확인 중...${NC}"
if [ ! -f "android/app/google-services.json" ]; then
    echo -e "${RED}❌ google-services.json을 찾을 수 없습니다!${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Firebase 설정 확인 완료${NC}"
echo ""

echo -e "${GREEN}[2/5] 이전 빌드 파일 정리 중...${NC}"
cd android
./gradlew clean
echo -e "${GREEN}✅ 정리 완료${NC}"
echo ""

echo -e "${GREEN}[3/5] APK 빌드 중... (약 3-5분 소요)${NC}"
echo -e "${YELLOW}⏳ 잠시만 기다려주세요...${NC}"
echo ""
./gradlew assembleRelease

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ APK 빌드 성공!${NC}"
    echo ""
else
    echo ""
    echo -e "${RED}❌ APK 빌드 실패!${NC}"
    exit 1
fi

echo -e "${GREEN}[4/5] APK 파일 복사 중...${NC}"
APK_SOURCE="app/build/outputs/apk/release/app-release.apk"
APK_DEST="/home/user/SayToDo.apk"

if [ -f "$APK_SOURCE" ]; then
    cp "$APK_SOURCE" "$APK_DEST"
    echo -e "${GREEN}✅ APK 파일 복사 완료${NC}"
    echo ""
else
    echo -e "${RED}❌ APK 파일을 찾을 수 없습니다!${NC}"
    exit 1
fi

echo -e "${GREEN}[5/5] APK 정보 확인 중...${NC}"
APK_SIZE=$(du -h "$APK_DEST" | cut -f1)
echo -e "${GREEN}✅ APK 크기: $APK_SIZE${NC}"
echo ""

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  🎉 APK 빌드 완료!${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${YELLOW}📱 APK 파일 위치:${NC}"
echo -e "   $APK_DEST"
echo ""
echo -e "${YELLOW}📦 파일 크기: $APK_SIZE${NC}"
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${GREEN}📲 설치 방법:${NC}"
echo ""
echo -e "  1️⃣  APK 파일을 모바일로 전송"
echo -e "      (이메일, USB, 클라우드 등)"
echo ""
echo -e "  2️⃣  모바일에서 APK 파일 실행"
echo -e "      (출처를 알 수 없는 앱 허용 필요)"
echo ""
echo -e "  3️⃣  '설치' 버튼 클릭"
echo ""
echo -e "  4️⃣  설치 완료 후 SayToDo 앱 실행"
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${YELLOW}⚠️  주의사항:${NC}"
echo ""
echo -e "  • 이 APK는 디버그 서명으로 빌드되었습니다"
echo -e "  • Google Play 스토어에 배포하려면 릴리즈 서명 필요"
echo -e "  • Firebase와 Google 로그인이 정상 작동합니다"
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# APK 파일 목록 출력
ls -lh "$APK_DEST"
echo ""

