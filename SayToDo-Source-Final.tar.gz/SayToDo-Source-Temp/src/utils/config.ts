export const API_CONFIG = {
  // 백엔드 서버 URL - 실제 배포 시 변경 필요
  BASE_URL: 'https://3002-i831dov1p3qmbwxmdvsyx-5634da27.sandbox.novita.ai',
  
  // API 엔드포인트
  ENDPOINTS: {
    // 인증
    REGISTER: '/api/auth/register',
    LOGIN: '/api/auth/login',
    GOOGLE_LOGIN: '/api/auth/google-login',
    FCM_TOKEN: '/api/auth/fcm-token',
    
    // 채널
    CREATE_CHANNEL: '/api/channels/create',
    MY_CHANNELS: '/api/channels/my-channels',
    CHANNEL_DETAIL: (id: string) => `/api/channels/${id}`,
    ADD_MEMBER: (id: string) => `/api/channels/${id}/add-member`,
    LEAVE_CHANNEL: (id: string) => `/api/channels/${id}/leave`,
    JOIN_BY_CODE: '/api/channels/join-by-code',
    REGENERATE_CODE: (id: string) => `/api/channels/${id}/regenerate-code`,
    
    // 알림
    SEND_ALERT: '/api/alerts/send',
    RESPOND_ALERT: '/api/alerts/respond',
    ALERT_DETAIL: (id: string) => `/api/alerts/${id}`,
    CHANNEL_ALERTS: (id: string) => `/api/alerts/channel/${id}/history`,
    
    // 미디어
    UPLOAD_MEDIA: '/api/media/upload',
    MEDIA_DETAIL: (id: string) => `/api/media/${id}`,
    MY_UPLOADS: '/api/media/my/uploads',
    DELETE_MEDIA: (id: string) => `/api/media/${id}`,
  },
  
  // 타임아웃 설정
  TIMEOUT: 30000,
};

export default API_CONFIG;
