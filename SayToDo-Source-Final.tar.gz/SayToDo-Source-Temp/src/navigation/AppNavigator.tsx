import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ChannelsListScreen from '../screens/ChannelsListScreen';
import ChannelDetailScreen from '../screens/ChannelDetailScreen';
import CreateChannelScreen from '../screens/CreateChannelScreen';
import SendAlertScreen from '../screens/SendAlertScreen';
import JoinChannelScreen from '../screens/JoinChannelScreen';
import MediaPlayerScreen from '../screens/MediaPlayerScreen';

export type RootStackParamList = {
  ChannelsList: undefined;
  ChannelDetail: { channelId: string };
  CreateChannel: undefined;
  SendAlert: { channelId: string };
  JoinChannel: undefined;
  MediaPlayer: {
    mediaType: 'audio' | 'video' | 'youtube';
    mediaUrl: string;
    channelName: string;
    senderName: string;
  };
};

const Stack = createStackNavigator<RootStackParamList>();

const AppNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="ChannelsList"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#4285F4',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Stack.Screen
          name="ChannelsList"
          component={ChannelsListScreen}
          options={{ title: '채널 목록' }}
        />
        <Stack.Screen
          name="ChannelDetail"
          component={ChannelDetailScreen}
          options={{ title: '채널 상세' }}
        />
        <Stack.Screen
          name="CreateChannel"
          component={CreateChannelScreen}
          options={{ title: '채널 생성' }}
        />
        <Stack.Screen
          name="SendAlert"
          component={SendAlertScreen}
          options={{ title: '알림 발송' }}
        />
        <Stack.Screen
          name="JoinChannel"
          component={JoinChannelScreen}
          options={{ title: '채널 가입' }}
        />
        <Stack.Screen
          name="MediaPlayer"
          component={MediaPlayerScreen}
          options={{ 
            title: '재생',
            headerShown: false, // 전체 화면 플레이어
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
