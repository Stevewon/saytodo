// 사용자
export interface User {
  id: string;
  email: string;
  nickname: string;
  fcm_token?: string;
}

// 채널
export interface Channel {
  id: string;
  name: string;
  description?: string;
  creator_id: string;
  creator_nickname?: string;
  invite_code?: string;
  role?: 'admin' | 'member';
  created_at: string;
}

// 채널 멤버
export interface ChannelMember {
  id: string;
  nickname: string;
  email: string;
  role: 'admin' | 'member';
  joined_at: string;
}

// 알림
export interface Alert {
  id: string;
  channel_id: string;
  channel_name?: string;
  sender_id: string;
  sender_nickname?: string;
  title: string;
  message?: string;
  media_type?: 'audio' | 'short_video' | 'youtube_video';
  media_url?: string;
  youtube_url?: string;
  created_at: string;
}

// 알림 응답
export interface AlertResponse {
  id: string;
  alert_id: string;
  user_id: string;
  response: 'accepted' | 'rejected' | 'missed';
  responded_at: string;
}

// 알림 통계
export interface AlertStats {
  total: number;
  accepted: number;
  rejected: number;
  missed: number;
}

// 미디어 파일
export interface MediaFile {
  id: string;
  uploader_id: string;
  filename: string;
  original_filename: string;
  file_type: 'audio' | 'video';
  file_size: number;
  file_path: string;
  duration?: number;
  created_at: string;
}

// FCM 푸시 데이터
export interface FCMAlertData {
  type: 'voip_alert';
  alertId: string;
  channelId: string;
  channelName: string;
  title: string;
  message: string;
  mediaType: string;
  mediaUrl: string;
  youtubeUrl: string;
  senderId: string;
  senderName: string;
  timestamp: string;
}

// API 응답
export interface ApiResponse<T = any> {
  message?: string;
  data?: T;
  error?: string;
}
