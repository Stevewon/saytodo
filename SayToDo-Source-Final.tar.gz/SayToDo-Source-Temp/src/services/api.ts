import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_CONFIG } from '../utils/config';

class ApiService {
  private api: AxiosInstance;

  constructor() {
    this.api = axios.create({
      baseURL: API_CONFIG.BASE_URL,
      timeout: API_CONFIG.TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // 요청 인터셉터: 토큰 자동 추가
    this.api.interceptors.request.use(
      async (config) => {
        const token = await AsyncStorage.getItem('authToken');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // 응답 인터셉터: 에러 처리
    this.api.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          // 토큰 만료 시 로그아웃
          await AsyncStorage.removeItem('authToken');
          await AsyncStorage.removeItem('user');
        }
        return Promise.reject(error);
      }
    );
  }

  // 인증
  async register(email: string, password: string, nickname: string) {
    const response = await this.api.post(API_CONFIG.ENDPOINTS.REGISTER, {
      email,
      password,
      nickname,
    });
    return response.data;
  }

  async login(email: string, password: string) {
    const response = await this.api.post(API_CONFIG.ENDPOINTS.LOGIN, {
      email,
      password,
    });
    return response.data;
  }

  async googleLogin(email: string, name: string, photoUrl: string, googleId: string) {
    const response = await this.api.post(API_CONFIG.ENDPOINTS.GOOGLE_LOGIN, {
      email,
      name,
      photoUrl,
      googleId,
    });
    return response.data;
  }

  async updateFcmToken(userId: string, fcmToken: string) {
    const response = await this.api.post(API_CONFIG.ENDPOINTS.FCM_TOKEN, {
      userId,
      fcmToken,
    });
    return response.data;
  }

  // 채널
  async createChannel(name: string, description?: string) {
    const response = await this.api.post(API_CONFIG.ENDPOINTS.CREATE_CHANNEL, {
      name,
      description,
    });
    return response.data;
  }

  async getMyChannels() {
    const response = await this.api.get(API_CONFIG.ENDPOINTS.MY_CHANNELS);
    return response.data;
  }

  async getChannelDetail(channelId: string) {
    const response = await this.api.get(
      API_CONFIG.ENDPOINTS.CHANNEL_DETAIL(channelId)
    );
    return response.data;
  }

  async addChannelMember(channelId: string, email: string) {
    const response = await this.api.post(
      API_CONFIG.ENDPOINTS.ADD_MEMBER(channelId),
      { email }
    );
    return response.data;
  }

  async leaveChannel(channelId: string) {
    const response = await this.api.delete(
      API_CONFIG.ENDPOINTS.LEAVE_CHANNEL(channelId)
    );
    return response.data;
  }

  async joinChannelByCode(inviteCode: string) {
    const response = await this.api.post(API_CONFIG.ENDPOINTS.JOIN_BY_CODE, {
      inviteCode,
    });
    return response.data;
  }

  async regenerateInviteCode(channelId: string) {
    const response = await this.api.post(
      API_CONFIG.ENDPOINTS.REGENERATE_CODE(channelId)
    );
    return response.data;
  }

  // 알림
  async sendAlert(
    channelId: string,
    title: string,
    message?: string,
    mediaType?: string,
    mediaUrl?: string,
    youtubeUrl?: string
  ) {
    const response = await this.api.post(API_CONFIG.ENDPOINTS.SEND_ALERT, {
      channelId,
      title,
      message,
      mediaType,
      mediaUrl,
      youtubeUrl,
    });
    return response.data;
  }

  async respondAlert(alertId: string, response: 'accepted' | 'rejected') {
    const result = await this.api.post(API_CONFIG.ENDPOINTS.RESPOND_ALERT, {
      alertId,
      response,
    });
    return result.data;
  }

  async getAlertDetail(alertId: string) {
    const response = await this.api.get(
      API_CONFIG.ENDPOINTS.ALERT_DETAIL(alertId)
    );
    return response.data;
  }

  async getChannelAlerts(channelId: string) {
    const response = await this.api.get(
      API_CONFIG.ENDPOINTS.CHANNEL_ALERTS(channelId)
    );
    return response.data;
  }

  // 미디어
  async uploadMedia(file: any) {
    const formData = new FormData();
    formData.append('media', file);

    const response = await this.api.post(
      API_CONFIG.ENDPOINTS.UPLOAD_MEDIA,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    return response.data;
  }

  async getMediaDetail(mediaId: string) {
    const response = await this.api.get(
      API_CONFIG.ENDPOINTS.MEDIA_DETAIL(mediaId)
    );
    return response.data;
  }

  async getMyUploads() {
    const response = await this.api.get(API_CONFIG.ENDPOINTS.MY_UPLOADS);
    return response.data;
  }

  async deleteMedia(mediaId: string) {
    const response = await this.api.delete(
      API_CONFIG.ENDPOINTS.DELETE_MEDIA(mediaId)
    );
    return response.data;
  }

  // 파일 URL 생성
  getMediaUrl(path: string): string {
    if (path.startsWith('http')) {
      return path;
    }
    return `${API_CONFIG.BASE_URL}${path}`;
  }
}

export default new ApiService();
