/**
 * Deep Link Service
 * 초대 링크 생성 및 처리
 */

import { Linking } from 'react-native';

export interface InviteLink {
  inviteCode: string;
  channelId?: string;
}

export class DeepLinkService {
  private static listeners: ((link: InviteLink) => void)[] = [];

  /**
   * 딥링크 리스너 초기화
   */
  static initialize() {
    // 앱이 닫혀있을 때 링크로 실행된 경우
    Linking.getInitialURL().then((url) => {
      if (url) {
        this.handleDeepLink(url);
      }
    });

    // 앱이 실행 중일 때 링크 클릭
    Linking.addEventListener('url', (event) => {
      this.handleDeepLink(event.url);
    });
  }

  /**
   * 딥링크 URL 파싱 및 처리
   */
  private static handleDeepLink(url: string) {
    try {
      console.log('Deep link received:', url);

      const parsedLink = this.parseInviteLink(url);
      if (parsedLink) {
        // 모든 리스너에게 알림
        this.listeners.forEach((listener) => listener(parsedLink));
      }
    } catch (error) {
      console.error('Deep link parsing error:', error);
    }
  }

  /**
   * 초대 링크 파싱
   * 지원 형식:
   * - saytodo://join/ABC123
   * - https://saytodo.app/join/ABC123
   */
  private static parseInviteLink(url: string): InviteLink | null {
    try {
      // saytodo://join/ABC123
      if (url.startsWith('saytodo://join/')) {
        const inviteCode = url.replace('saytodo://join/', '');
        return { inviteCode };
      }

      // https://saytodo.app/join/ABC123
      if (url.includes('saytodo.app/join/')) {
        const parts = url.split('/join/');
        if (parts.length === 2) {
          const inviteCode = parts[1];
          return { inviteCode };
        }
      }

      return null;
    } catch (error) {
      console.error('Link parsing error:', error);
      return null;
    }
  }

  /**
   * 초대 링크 생성
   */
  static generateInviteLink(inviteCode: string): string {
    // 딥링크 형식 (앱에서 바로 열림)
    return `saytodo://join/${inviteCode}`;
  }

  /**
   * 공유용 웹 링크 생성 (선택적)
   */
  static generateWebLink(inviteCode: string): string {
    // 웹 링크 형식 (브라우저에서 앱으로 리다이렉트)
    return `https://saytodo.app/join/${inviteCode}`;
  }

  /**
   * 딥링크 리스너 등록
   */
  static addListener(callback: (link: InviteLink) => void) {
    this.listeners.push(callback);
  }

  /**
   * 딥링크 리스너 제거
   */
  static removeListener(callback: (link: InviteLink) => void) {
    this.listeners = this.listeners.filter((listener) => listener !== callback);
  }

  /**
   * 초대 링크 공유
   */
  static async shareInviteLink(inviteCode: string, channelName: string): Promise<boolean> {
    try {
      const { Share } = require('react-native');
      const link = this.generateInviteLink(inviteCode);
      
      const result = await Share.share({
        message: `SayToDo 채널에 초대합니다!\n\n채널: ${channelName}\n\n아래 링크를 클릭하여 가입하세요:\n${link}`,
        url: link,
        title: `${channelName} 채널 초대`,
      });

      return result.action === Share.sharedAction;
    } catch (error) {
      console.error('Share error:', error);
      return false;
    }
  }

  /**
   * 전화번호부 연락처와 공유
   */
  static async shareToContacts(inviteCode: string, channelName: string): Promise<boolean> {
    try {
      const { Share } = require('react-native');
      const link = this.generateInviteLink(inviteCode);
      
      const message = `안녕하세요! SayToDo 채널 "${channelName}"에 초대합니다.\n\n아래 링크를 클릭하면 바로 가입할 수 있습니다:\n${link}\n\nSayToDo 앱 다운로드:\nhttps://play.google.com/store/apps/details?id=com.saytodo`;

      const result = await Share.share({
        message,
        title: `${channelName} 채널 초대`,
      });

      return result.action === Share.sharedAction;
    } catch (error) {
      console.error('Share to contacts error:', error);
      return false;
    }
  }

  /**
   * SMS로 초대 링크 보내기
   */
  static async sendViaSMS(inviteCode: string, channelName: string, phoneNumber?: string): Promise<boolean> {
    try {
      const { Linking } = require('react-native');
      const link = this.generateInviteLink(inviteCode);
      
      const message = `SayToDo 채널 "${channelName}" 초대 링크: ${link}`;
      const url = phoneNumber 
        ? `sms:${phoneNumber}?body=${encodeURIComponent(message)}`
        : `sms:?body=${encodeURIComponent(message)}`;

      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
        return true;
      }
      return false;
    } catch (error) {
      console.error('SMS send error:', error);
      return false;
    }
  }

  /**
   * 카카오톡으로 공유 (선택적)
   */
  static async shareViaKakao(inviteCode: string, channelName: string): Promise<boolean> {
    try {
      // 카카오톡 SDK 연동 시 구현
      // 현재는 일반 공유로 대체
      return await this.shareInviteLink(inviteCode, channelName);
    } catch (error) {
      console.error('Kakao share error:', error);
      return false;
    }
  }
}

export default DeepLinkService;
