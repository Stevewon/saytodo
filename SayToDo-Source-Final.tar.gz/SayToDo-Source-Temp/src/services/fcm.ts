import messaging from '@react-native-firebase/messaging';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ApiService from './api';
import { FCMAlertData } from '../types';

class FCMService {
  private static instance: FCMService;

  private constructor() {}

  static getInstance(): FCMService {
    if (!FCMService.instance) {
      FCMService.instance = new FCMService();
    }
    return FCMService.instance;
  }

  // FCM 권한 요청
  async requestPermission(): Promise<boolean> {
    try {
      const authStatus = await messaging().requestPermission();
      const enabled =
        authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
        authStatus === messaging.AuthorizationStatus.PROVISIONAL;

      if (enabled) {
        console.log('FCM Authorization status:', authStatus);
        return true;
      }
      return false;
    } catch (error) {
      console.error('FCM Permission request error:', error);
      return false;
    }
  }

  // FCM 토큰 가져오기 및 서버 등록
  async registerDevice(): Promise<string | null> {
    try {
      const token = await messaging().getToken();
      console.log('FCM Token:', token);

      // AsyncStorage에 저장
      await AsyncStorage.setItem('fcmToken', token);

      // 서버에 등록
      const userJson = await AsyncStorage.getItem('user');
      if (userJson) {
        const user = JSON.parse(userJson);
        await ApiService.updateFcmToken(user.id, token);
        console.log('FCM token registered to server');
      }

      return token;
    } catch (error) {
      console.error('Failed to get FCM token:', error);
      return null;
    }
  }

  // FCM 토큰 갱신 리스너
  onTokenRefresh(callback: (token: string) => void) {
    return messaging().onTokenRefresh(async (token) => {
      console.log('FCM Token refreshed:', token);
      await AsyncStorage.setItem('fcmToken', token);
      
      // 서버에 업데이트
      const userJson = await AsyncStorage.getItem('user');
      if (userJson) {
        const user = JSON.parse(userJson);
        await ApiService.updateFcmToken(user.id, token);
      }
      
      callback(token);
    });
  }

  // 포그라운드 메시지 수신
  onForegroundMessage(callback: (data: FCMAlertData) => void) {
    return messaging().onMessage(async (remoteMessage) => {
      console.log('Foreground FCM Message:', remoteMessage);
      
      if (remoteMessage.data?.type === 'voip_alert') {
        const alertData = remoteMessage.data as unknown as FCMAlertData;
        callback(alertData);
      }
    });
  }

  // 백그라운드 메시지 핸들러 설정 (index.js에서 호출)
  static setBackgroundMessageHandler() {
    messaging().setBackgroundMessageHandler(async (remoteMessage) => {
      console.log('Background FCM Message:', remoteMessage);
      // 백그라운드에서는 네이티브 알림이 자동으로 표시됨
    });
  }

  // 알림 클릭으로 앱 열림
  onNotificationOpenedApp(callback: (data: FCMAlertData) => void) {
    // 앱이 백그라운드에서 알림으로 열림
    messaging().onNotificationOpenedApp((remoteMessage) => {
      console.log('Notification opened app from background:', remoteMessage);
      if (remoteMessage.data?.type === 'voip_alert') {
        const alertData = remoteMessage.data as unknown as FCMAlertData;
        callback(alertData);
      }
    });
  }

  // 앱이 종료 상태에서 알림으로 열림
  async getInitialNotification(): Promise<FCMAlertData | null> {
    const remoteMessage = await messaging().getInitialNotification();
    if (remoteMessage && remoteMessage.data?.type === 'voip_alert') {
      console.log('App opened from quit state by notification:', remoteMessage);
      return remoteMessage.data as unknown as FCMAlertData;
    }
    return null;
  }

  // FCM 초기화
  async initialize(
    onForegroundMessage: (data: FCMAlertData) => void,
    onNotificationOpened: (data: FCMAlertData) => void
  ): Promise<boolean> {
    try {
      // 권한 요청
      const hasPermission = await this.requestPermission();
      if (!hasPermission) {
        console.warn('FCM permission not granted');
        return false;
      }

      // 디바이스 등록
      await this.registerDevice();

      // 토큰 갱신 리스너
      this.onTokenRefresh((token) => {
        console.log('New FCM token:', token);
      });

      // 포그라운드 메시지 리스너
      this.onForegroundMessage(onForegroundMessage);

      // 알림 클릭 리스너
      this.onNotificationOpenedApp(onNotificationOpened);

      // 초기 알림 확인 (앱이 종료 상태에서 알림으로 열림)
      const initialNotification = await this.getInitialNotification();
      if (initialNotification) {
        onNotificationOpened(initialNotification);
      }

      console.log('FCM Service initialized successfully');
      return true;
    } catch (error) {
      console.error('FCM initialization error:', error);
      return false;
    }
  }
}

export default FCMService.getInstance();
