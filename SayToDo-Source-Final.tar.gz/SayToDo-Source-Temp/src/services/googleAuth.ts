import { GoogleSignin } from '@react-native-google-signin/google-signin';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ApiService from './api';

class GoogleAuthService {
  private static instance: GoogleAuthService;

  private constructor() {}

  static getInstance(): GoogleAuthService {
    if (!GoogleAuthService.instance) {
      GoogleAuthService.instance = new GoogleAuthService();
    }
    return GoogleAuthService.instance;
  }

  // Google Sign-In 초기화
  configure(webClientId: string) {
    GoogleSignin.configure({
      webClientId: webClientId, // Firebase Console에서 가져온 Web Client ID
      offlineAccess: true,
      forceCodeForRefreshToken: true,
    });
  }

  // 구글 로그인
  async signIn(): Promise<{
    success: boolean;
    user?: any;
    token?: string;
    error?: string;
  }> {
    try {
      // Google Play Services 확인
      await GoogleSignin.hasPlayServices();

      // 구글 로그인
      const userInfo = await GoogleSignin.signIn();
      
      if (!userInfo.data) {
        return { success: false, error: '구글 로그인 정보를 가져올 수 없습니다' };
      }

      const { user } = userInfo.data;

      console.log('Google Sign-In success:', user);

      // 백엔드 서버에 구글 로그인 요청 (자동 가입/로그인)
      const response = await ApiService.googleLogin(
        user.email,
        user.name || user.email.split('@')[0],
        user.photo || '',
        user.id
      );

      // 토큰 및 사용자 정보 저장
      await AsyncStorage.setItem('authToken', response.token);
      await AsyncStorage.setItem('user', JSON.stringify(response.user));

      return {
        success: true,
        user: response.user,
        token: response.token,
      };
    } catch (error: any) {
      console.error('Google Sign-In error:', error);
      return {
        success: false,
        error: error.message || '구글 로그인 실패',
      };
    }
  }

  // 현재 사용자 정보 가져오기
  async getCurrentUser() {
    try {
      const userInfo = await GoogleSignin.signInSilently();
      return userInfo;
    } catch (error) {
      console.error('Get current user error:', error);
      return null;
    }
  }

  // 로그아웃
  async signOut() {
    try {
      await GoogleSignin.signOut();
      await AsyncStorage.removeItem('authToken');
      await AsyncStorage.removeItem('user');
      await AsyncStorage.removeItem('fcmToken');
      console.log('Google Sign-Out success');
    } catch (error) {
      console.error('Google Sign-Out error:', error);
    }
  }

  // 구글 계정 연결 해제
  async revokeAccess() {
    try {
      await GoogleSignin.revokeAccess();
      await AsyncStorage.clear();
      console.log('Google account revoked');
    } catch (error) {
      console.error('Revoke access error:', error);
    }
  }

  // 로그인 상태 확인
  async isSignedIn(): Promise<boolean> {
    return await GoogleSignin.isSignedIn();
  }
}

export default GoogleAuthService.getInstance();
