import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import ApiService from '../services/api';

type NavigationProp = StackNavigationProp<RootStackParamList, 'SendAlert'>;
type ScreenRouteProp = RouteProp<RootStackParamList, 'SendAlert'>;

type MediaType = 'audio' | 'short_video' | 'youtube_video' | null;

const SendAlertScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<ScreenRouteProp>();
  const { channelId } = route.params;

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [mediaType, setMediaType] = useState<MediaType>(null);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!title.trim()) {
      Alert.alert('입력 오류', '제목을 입력해주세요.');
      return;
    }

    if (mediaType === 'youtube_video' && !youtubeUrl.trim()) {
      Alert.alert('입력 오류', 'YouTube URL을 입력해주세요.');
      return;
    }

    Alert.alert(
      '알림 발송',
      '채널의 모든 멤버에게 긴급 알림을 발송하시겠습니까?',
      [
        { text: '취소', style: 'cancel' },
        {
          text: '발송',
          onPress: async () => {
            try {
              setSending(true);
              
              await ApiService.sendAlert(
                channelId,
                title.trim(),
                message.trim() || undefined,
                mediaType || undefined,
                undefined, // mediaUrl는 파일 업로드 후 사용
                mediaType === 'youtube_video' ? youtubeUrl.trim() : undefined
              );

              Alert.alert(
                '발송 완료',
                '긴급 알림이 성공적으로 발송되었습니다!',
                [
                  {
                    text: '확인',
                    onPress: () => navigation.goBack(),
                  },
                ]
              );
            } catch (error: any) {
              console.error('Send alert error:', error);
              Alert.alert('오류', '알림 발송에 실패했습니다. 다시 시도해주세요.');
            } finally {
              setSending(false);
            }
          },
        },
      ]
    );
  };

  const renderMediaTypeButton = (
    type: MediaType,
    label: string,
    emoji: string,
    description: string
  ) => {
    const isSelected = mediaType === type;
    
    return (
      <TouchableOpacity
        style={[
          styles.mediaTypeButton,
          isSelected && styles.mediaTypeButtonSelected,
        ]}
        onPress={() => setMediaType(type)}
      >
        <Text style={styles.mediaTypeEmoji}>{emoji}</Text>
        <Text style={[
          styles.mediaTypeLabel,
          isSelected && styles.mediaTypeLabelSelected,
        ]}>
          {label}
        </Text>
        <Text style={[
          styles.mediaTypeDescription,
          isSelected && styles.mediaTypeDescriptionSelected,
        ]}>
          {description}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* 안내 */}
        <View style={styles.warningBox}>
          <Text style={styles.warningEmoji}>⚠️</Text>
          <Text style={styles.warningText}>
            전화벨처럼 울리는 긴급 알림입니다.{'\n'}
            정말 중요한 경우에만 사용하세요!
          </Text>
        </View>

        {/* 제목 입력 */}
        <View style={styles.inputSection}>
          <Text style={styles.label}>
            제목 <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            placeholder="긴급 알림 제목을 입력하세요"
            value={title}
            onChangeText={setTitle}
            maxLength={100}
            autoFocus
          />
          <Text style={styles.helperText}>{title.length}/100</Text>
        </View>

        {/* 메시지 입력 */}
        <View style={styles.inputSection}>
          <Text style={styles.label}>메시지 (선택)</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="추가 메시지를 입력하세요"
            value={message}
            onChangeText={setMessage}
            maxLength={500}
            multiline
            numberOfLines={5}
            textAlignVertical="top"
          />
          <Text style={styles.helperText}>{message.length}/500</Text>
        </View>

        {/* 미디어 타입 선택 */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>미디어 첨부 (선택)</Text>
          <View style={styles.mediaTypesContainer}>
            {renderMediaTypeButton(
              null,
              '없음',
              '📝',
              '텍스트만 전송'
            )}
            {renderMediaTypeButton(
              'audio',
              '음성',
              '🎤',
              '음성 메시지 (준비중)'
            )}
            {renderMediaTypeButton(
              'short_video',
              '짧은 영상',
              '🎬',
              '영상 파일 (준비중)'
            )}
            {renderMediaTypeButton(
              'youtube_video',
              'YouTube',
              '📺',
              'YouTube 링크'
            )}
          </View>
        </View>

        {/* YouTube URL 입력 */}
        {mediaType === 'youtube_video' && (
          <View style={styles.inputSection}>
            <Text style={styles.label}>
              YouTube URL <Text style={styles.required}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              placeholder="https://www.youtube.com/watch?v=..."
              value={youtubeUrl}
              onChangeText={setYoutubeUrl}
              keyboardType="url"
              autoCapitalize="none"
            />
            <Text style={styles.helperText}>
              YouTube 영상 URL을 입력하세요
            </Text>
          </View>
        )}

        {/* 미디어 업로드 안내 */}
        {(mediaType === 'audio' || mediaType === 'short_video') && (
          <View style={styles.comingSoonBox}>
            <Text style={styles.comingSoonText}>
              🚧 파일 업로드 기능은 곧 추가됩니다!
            </Text>
          </View>
        )}

        {/* 발송 버튼 */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.button, styles.cancelButton]}
            onPress={() => navigation.goBack()}
            disabled={sending}
          >
            <Text style={styles.cancelButtonText}>취소</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.sendButton]}
            onPress={handleSend}
            disabled={sending || !title.trim()}
          >
            {sending ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.sendButtonText}>📢 발송하기</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollContent: {
    padding: 16,
  },
  warningBox: {
    backgroundColor: '#FFF3E0',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  warningEmoji: {
    fontSize: 32,
    marginRight: 12,
  },
  warningText: {
    flex: 1,
    fontSize: 14,
    color: '#E65100',
    lineHeight: 20,
  },
  inputSection: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  required: {
    color: '#f44336',
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  textArea: {
    minHeight: 120,
    paddingTop: 12,
  },
  helperText: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
    textAlign: 'right',
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  mediaTypesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  mediaTypeButton: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#fff',
    borderWidth: 2,
    borderColor: '#ddd',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  mediaTypeButtonSelected: {
    borderColor: '#4285F4',
    backgroundColor: '#E3F2FD',
  },
  mediaTypeEmoji: {
    fontSize: 32,
    marginBottom: 8,
  },
  mediaTypeLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  mediaTypeLabelSelected: {
    color: '#4285F4',
  },
  mediaTypeDescription: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
  },
  mediaTypeDescriptionSelected: {
    color: '#1976D2',
  },
  comingSoonBox: {
    backgroundColor: '#E0F2F1',
    borderRadius: 8,
    padding: 16,
    marginBottom: 20,
    alignItems: 'center',
  },
  comingSoonText: {
    fontSize: 14,
    color: '#00796B',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 20,
    marginBottom: 40,
  },
  button: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
  },
  sendButton: {
    backgroundColor: '#FF5722',
  },
  sendButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
});

export default SendAlertScreen;
