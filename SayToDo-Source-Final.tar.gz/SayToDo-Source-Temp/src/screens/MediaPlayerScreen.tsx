/**
 * Media Player Screen
 * 음성/영상 재생 화면
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { useRoute, useNavigation, RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../navigation/AppNavigator';

type ScreenRouteProp = RouteProp<RootStackParamList, 'MediaPlayer'>;

interface MediaPlayerScreenProps {}

const MediaPlayerScreen: React.FC<MediaPlayerScreenProps> = () => {
  const route = useRoute<ScreenRouteProp>();
  const navigation = useNavigation();
  const { mediaType, mediaUrl, channelName, senderName } = route.params;

  const [loading, setLoading] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadMedia();
  }, []);

  const loadMedia = async () => {
    try {
      setLoading(true);
      setError(null);

      // 미디어 타입에 따라 플레이어 로드
      if (mediaType === 'audio') {
        await loadAudio();
      } else if (mediaType === 'video') {
        await loadVideo();
      } else if (mediaType === 'youtube') {
        await loadYouTube();
      }

      setLoading(false);
    } catch (err: any) {
      console.error('Load media error:', err);
      setError(err.message || '미디어를 불러오는데 실패했습니다.');
      setLoading(false);
    }
  };

  const loadAudio = async () => {
    // react-native-sound 사용
    console.log('Loading audio:', mediaUrl);
    // TODO: 실제 구현
  };

  const loadVideo = async () => {
    // react-native-video 사용
    console.log('Loading video:', mediaUrl);
    // TODO: 실제 구현
  };

  const loadYouTube = async () => {
    // react-native-youtube-iframe 사용
    console.log('Loading YouTube:', mediaUrl);
    // TODO: 실제 구현
  };

  const handlePlayPause = () => {
    setPlaying(!playing);
    // TODO: 실제 재생/일시정지 구현
  };

  const handleStop = () => {
    setPlaying(false);
    // TODO: 실제 정지 구현
    navigation.goBack();
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4285F4" />
          <Text style={styles.loadingText}>불러오는 중...</Text>
        </View>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorIcon}>⚠️</Text>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity
            style={styles.retryButton}
            onPress={loadMedia}
          >
            <Text style={styles.retryButtonText}>다시 시도</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.closeButtonText}>닫기</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* 헤더 */}
      <View style={styles.header}>
        <View style={styles.headerInfo}>
          <Text style={styles.channelName}>{channelName}</Text>
          <Text style={styles.senderName}>보낸 사람: {senderName}</Text>
        </View>
      </View>

      {/* 미디어 플레이어 */}
      <View style={styles.playerContainer}>
        {mediaType === 'audio' && (
          <AudioPlayer
            url={mediaUrl}
            playing={playing}
            onPlayingChange={setPlaying}
          />
        )}
        {mediaType === 'video' && (
          <VideoPlayer
            url={mediaUrl}
            playing={playing}
            onPlayingChange={setPlaying}
          />
        )}
        {mediaType === 'youtube' && (
          <YouTubePlayer
            url={mediaUrl}
            playing={playing}
            onPlayingChange={setPlaying}
          />
        )}
      </View>

      {/* 컨트롤 버튼 */}
      <View style={styles.controls}>
        <TouchableOpacity
          style={[styles.controlButton, styles.playButton]}
          onPress={handlePlayPause}
        >
          <Text style={styles.controlButtonText}>
            {playing ? '⏸️ 일시정지' : '▶️ 재생'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.controlButton, styles.stopButton]}
          onPress={handleStop}
        >
          <Text style={styles.stopButtonText}>⏹️ 닫기</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// 음성 플레이어 컴포넌트
const AudioPlayer: React.FC<{
  url: string;
  playing: boolean;
  onPlayingChange: (playing: boolean) => void;
}> = ({ url, playing, onPlayingChange }) => {
  const [duration, setDuration] = useState(0);
  const [position, setPosition] = useState(0);

  return (
    <View style={styles.audioPlayer}>
      <View style={styles.audioIcon}>
        <Text style={styles.audioIconText}>🎵</Text>
      </View>
      <Text style={styles.audioTitle}>음성 메시지</Text>
      <View style={styles.audioProgress}>
        <View style={styles.progressBar}>
          <View
            style={[
              styles.progressFill,
              { width: duration > 0 ? `${(position / duration) * 100}%` : '0%' },
            ]}
          />
        </View>
        <View style={styles.timeContainer}>
          <Text style={styles.timeText}>{formatTime(position)}</Text>
          <Text style={styles.timeText}>{formatTime(duration)}</Text>
        </View>
      </View>
    </View>
  );
};

// 영상 플레이어 컴포넌트
const VideoPlayer: React.FC<{
  url: string;
  playing: boolean;
  onPlayingChange: (playing: boolean) => void;
}> = ({ url, playing, onPlayingChange }) => {
  return (
    <View style={styles.videoPlayer}>
      <View style={styles.videoPlaceholder}>
        <Text style={styles.videoPlaceholderText}>📹</Text>
        <Text style={styles.videoTitle}>영상 재생 중</Text>
      </View>
      {/* TODO: react-native-video 구현 */}
    </View>
  );
};

// YouTube 플레이어 컴포넌트
const YouTubePlayer: React.FC<{
  url: string;
  playing: boolean;
  onPlayingChange: (playing: boolean) => void;
}> = ({ url, playing, onPlayingChange }) => {
  return (
    <View style={styles.youtubePlayer}>
      <View style={styles.youtubePlaceholder}>
        <Text style={styles.youtubePlaceholderText}>📺</Text>
        <Text style={styles.youtubeTitle}>YouTube 영상</Text>
        <Text style={styles.youtubeUrl} numberOfLines={1}>
          {url}
        </Text>
      </View>
      {/* TODO: react-native-youtube-iframe 구현 */}
    </View>
  );
};

// 시간 포맷 헬퍼
const formatTime = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#fff',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  errorText: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 24,
  },
  retryButton: {
    backgroundColor: '#4285F4',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  retryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  closeButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  closeButtonText: {
    color: '#999',
    fontSize: 16,
  },
  header: {
    backgroundColor: 'rgba(0,0,0,0.8)',
    padding: 16,
  },
  headerInfo: {
    alignItems: 'center',
  },
  channelName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
  },
  senderName: {
    fontSize: 14,
    color: '#aaa',
  },
  playerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  controls: {
    padding: 20,
    gap: 12,
  },
  controlButton: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  playButton: {
    backgroundColor: '#4285F4',
  },
  stopButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#666',
  },
  controlButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  stopButtonText: {
    fontSize: 16,
    color: '#999',
  },
  // Audio Player
  audioPlayer: {
    width: width * 0.8,
    alignItems: 'center',
  },
  audioIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#4285F4',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  audioIconText: {
    fontSize: 60,
  },
  audioTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 32,
  },
  audioProgress: {
    width: '100%',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#333',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4285F4',
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  timeText: {
    fontSize: 12,
    color: '#999',
  },
  // Video Player
  videoPlayer: {
    width: width,
    height: height * 0.6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  videoPlaceholder: {
    alignItems: 'center',
  },
  videoPlaceholderText: {
    fontSize: 80,
    marginBottom: 16,
  },
  videoTitle: {
    fontSize: 18,
    color: '#fff',
  },
  // YouTube Player
  youtubePlayer: {
    width: width,
    height: height * 0.6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  youtubePlaceholder: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  youtubePlaceholderText: {
    fontSize: 80,
    marginBottom: 16,
  },
  youtubeTitle: {
    fontSize: 18,
    color: '#fff',
    marginBottom: 8,
  },
  youtubeUrl: {
    fontSize: 12,
    color: '#999',
    maxWidth: width * 0.8,
  },
});

export default MediaPlayerScreen;
