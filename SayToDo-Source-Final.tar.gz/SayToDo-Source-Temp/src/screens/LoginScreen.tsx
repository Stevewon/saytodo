import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import GoogleAuthService from '../services/googleAuth';

interface LoginScreenProps {
  onLoginSuccess: (user: any, token: string) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const result = await GoogleAuthService.signIn();
      
      if (result.success && result.user && result.token) {
        Alert.alert(
          '로그인 성공',
          `환영합니다, ${result.user.nickname}님!`,
          [
            {
              text: '확인',
              onPress: () => onLoginSuccess(result.user, result.token),
            },
          ]
        );
      } else {
        Alert.alert('로그인 실패', result.error || '알 수 없는 오류가 발생했습니다.');
      }
    } catch (error: any) {
      console.error('Login error:', error);
      Alert.alert('오류', error.message || '로그인 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {/* 로고 */}
        <View style={styles.logoContainer}>
          <Text style={styles.logoEmoji}>📞</Text>
          <Text style={styles.appName}>세이투두</Text>
          <Text style={styles.appSubtitle}>SayToDo</Text>
        </View>

        {/* 설명 */}
        <View style={styles.descriptionContainer}>
          <Text style={styles.description}>
            전화벨처럼 울리는{'\n'}할 일 알림 시스템
          </Text>
          <Text style={styles.descriptionSub}>
            중요한 메시지를 절대 놓치지 마세요
          </Text>
        </View>

        {/* 구글 로그인 버튼 */}
        <TouchableOpacity
          style={styles.googleButton}
          onPress={handleGoogleLogin}
          disabled={loading}
          activeOpacity={0.8}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <View style={styles.googleIconContainer}>
                <Text style={styles.googleIcon}>G</Text>
              </View>
              <Text style={styles.googleButtonText}>Google 계정으로 시작하기</Text>
            </>
          )}
        </TouchableOpacity>

        {/* 안내 문구 */}
        <Text style={styles.infoText}>
          구글 계정으로 로그인하면{'\n'}
          자동으로 가입 및 로그인됩니다
        </Text>
      </View>

      {/* 하단 정보 */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          로그인하면 서비스 이용약관 및{'\n'}
          개인정보 처리방침에 동의하게 됩니다
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  logoEmoji: {
    fontSize: 80,
    marginBottom: 20,
  },
  appName: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  appSubtitle: {
    fontSize: 18,
    color: '#999',
    letterSpacing: 2,
  },
  descriptionContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  description: {
    fontSize: 20,
    fontWeight: '600',
    color: '#555',
    textAlign: 'center',
    lineHeight: 28,
    marginBottom: 12,
  },
  descriptionSub: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
  googleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4285F4',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    width: '100%',
    maxWidth: 350,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  googleIconContainer: {
    width: 24,
    height: 24,
    backgroundColor: '#fff',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  googleIcon: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4285F4',
  },
  googleButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  infoText: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    marginTop: 20,
    lineHeight: 18,
  },
  footer: {
    paddingHorizontal: 30,
    paddingBottom: 30,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 11,
    color: '#ccc',
    textAlign: 'center',
    lineHeight: 16,
  },
});

export default LoginScreen;
