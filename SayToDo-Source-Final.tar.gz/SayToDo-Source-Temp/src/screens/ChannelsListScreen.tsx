import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import ApiService from '../services/api';
import { Channel } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';

type NavigationProp = StackNavigationProp<RootStackParamList, 'ChannelsList'>;

const ChannelsListScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    loadUser();
    loadChannels();
  }, []);

  const loadUser = async () => {
    try {
      const userJson = await AsyncStorage.getItem('user');
      if (userJson) {
        setUser(JSON.parse(userJson));
      }
    } catch (error) {
      console.error('Load user error:', error);
    }
  };

  const loadChannels = async () => {
    try {
      setLoading(true);
      const response = await ApiService.getMyChannels();
      setChannels(response.channels || []);
    } catch (error: any) {
      console.error('Load channels error:', error);
      Alert.alert('오류', '채널 목록을 불러오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadChannels();
    setRefreshing(false);
  }, []);

  const handleChannelPress = (channel: Channel) => {
    navigation.navigate('ChannelDetail', { channelId: channel.id });
  };

  const handleCreateChannel = () => {
    navigation.navigate('CreateChannel');
  };

  const handleJoinByCode = () => {
    navigation.navigate('JoinChannel');
  };

  const renderChannelItem = ({ item }: { item: Channel }) => {
    const isAdmin = item.role === 'admin';
    
    return (
      <TouchableOpacity
        style={styles.channelCard}
        onPress={() => handleChannelPress(item)}
        activeOpacity={0.7}
      >
        <View style={styles.channelHeader}>
          <View style={styles.channelInfo}>
            <Text style={styles.channelName}>{item.name}</Text>
            {item.description && (
              <Text style={styles.channelDescription} numberOfLines={2}>
                {item.description}
              </Text>
            )}
          </View>
          {isAdmin && (
            <View style={styles.adminBadge}>
              <Text style={styles.adminBadgeText}>관리자</Text>
            </View>
          )}
        </View>
        
        <View style={styles.channelFooter}>
          <Text style={styles.channelDate}>
            생성일: {new Date(item.created_at).toLocaleDateString()}
          </Text>
          {item.creator_nickname && (
            <Text style={styles.channelCreator}>
              생성자: {item.creator_nickname}
            </Text>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyEmoji}>📢</Text>
      <Text style={styles.emptyTitle}>가입한 채널이 없습니다</Text>
      <Text style={styles.emptyDescription}>
        새로운 채널을 만들거나{'\n'}
        초대 코드로 채널에 참여하세요
      </Text>
      <View style={styles.emptyButtons}>
        <TouchableOpacity
          style={styles.createButton}
          onPress={handleCreateChannel}
        >
          <Text style={styles.createButtonText}>+ 채널 만들기</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.joinButton}
          onPress={handleJoinByCode}
        >
          <Text style={styles.joinButtonText}>🔑 초대 코드로 가입</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4285F4" />
        <Text style={styles.loadingText}>채널 불러오는 중...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* 헤더 */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>내 채널</Text>
          {user && (
            <Text style={styles.headerSubtitle}>{user.nickname}님</Text>
          )}
        </View>
        <TouchableOpacity
          style={styles.headerButton}
          onPress={handleCreateChannel}
        >
          <Text style={styles.headerButtonText}>+ 새 채널</Text>
        </TouchableOpacity>
      </View>

      {/* 채널 목록 */}
      <FlatList
        data={channels}
        renderItem={renderChannelItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={renderEmptyState}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#999',
  },
  header: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#999',
    marginTop: 4,
  },
  headerButton: {
    backgroundColor: '#4285F4',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  headerButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  listContent: {
    padding: 16,
  },
  channelCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  channelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  channelInfo: {
    flex: 1,
    marginRight: 12,
  },
  channelName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 6,
  },
  channelDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  adminBadge: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  adminBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  channelFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 12,
  },
  channelDate: {
    fontSize: 12,
    color: '#999',
  },
  channelCreator: {
    fontSize: 12,
    color: '#999',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyEmoji: {
    fontSize: 64,
    marginBottom: 20,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 30,
  },
  emptyButtons: {
    flexDirection: 'column',
    gap: 12,
    width: '100%',
    paddingHorizontal: 20,
  },
  createButton: {
    backgroundColor: '#4285F4',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  createButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  joinButton: {
    backgroundColor: '#fff',
    borderWidth: 2,
    borderColor: '#4285F4',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  joinButtonText: {
    color: '#4285F4',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default ChannelsListScreen;
