import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  TextInput,
  Modal,
} from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import ApiService from '../services/api';
import DeepLinkService from '../services/deeplink';
import { Channel, ChannelMember } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';

type NavigationProp = StackNavigationProp<RootStackParamList, 'ChannelDetail'>;
type ScreenRouteProp = RouteProp<RootStackParamList, 'ChannelDetail'>;

const ChannelDetailScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<ScreenRouteProp>();
  const { channelId } = route.params;

  const [loading, setLoading] = useState(true);
  const [channel, setChannel] = useState<Channel | null>(null);
  const [members, setMembers] = useState<ChannelMember[]>([]);
  const [myRole, setMyRole] = useState<'admin' | 'member'>('member');
  const [userId, setUserId] = useState<string>('');
  
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [addingMember, setAddingMember] = useState(false);

  useEffect(() => {
    loadUserInfo();
    loadChannelDetail();
  }, [channelId]);

  const loadUserInfo = async () => {
    try {
      const userJson = await AsyncStorage.getItem('user');
      if (userJson) {
        const user = JSON.parse(userJson);
        setUserId(user.id);
      }
    } catch (error) {
      console.error('Load user error:', error);
    }
  };

  const loadChannelDetail = async () => {
    try {
      setLoading(true);
      const response = await ApiService.getChannelDetail(channelId);
      setChannel(response.channel);
      setMembers(response.members || []);
      setMyRole(response.myRole || 'member');
    } catch (error: any) {
      console.error('Load channel detail error:', error);
      Alert.alert('오류', '채널 정보를 불러오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendAlert = () => {
    navigation.navigate('SendAlert', { channelId });
  };

  const handleAddMember = async () => {
    if (!newMemberEmail.trim()) {
      Alert.alert('입력 오류', '이메일을 입력해주세요.');
      return;
    }

    try {
      setAddingMember(true);
      await ApiService.addChannelMember(channelId, newMemberEmail.trim());
      
      Alert.alert('성공', '멤버가 추가되었습니다.');
      setNewMemberEmail('');
      setShowAddMemberModal(false);
      loadChannelDetail();
    } catch (error: any) {
      console.error('Add member error:', error);
      Alert.alert('오류', error.response?.data?.error || '멤버 추가에 실패했습니다.');
    } finally {
      setAddingMember(false);
    }
  };

  const handleLeaveChannel = () => {
    Alert.alert(
      '채널 나가기',
      '정말 이 채널에서 나가시겠습니까?',
      [
        { text: '취소', style: 'cancel' },
        {
          text: '나가기',
          style: 'destructive',
          onPress: async () => {
            try {
              await ApiService.leaveChannel(channelId);
              Alert.alert('완료', '채널에서 나갔습니다.', [
                { text: '확인', onPress: () => navigation.goBack() },
              ]);
            } catch (error: any) {
              Alert.alert('오류', error.response?.data?.error || '채널 나가기에 실패했습니다.');
            }
          },
        },
      ]
    );
  };

  const handleShareInviteLink = async () => {
    if (!channel?.invite_code) {
      Alert.alert('오류', '초대 코드가 없습니다.');
      return;
    }

    Alert.alert(
      '초대 링크 공유',
      '어떻게 공유하시겠습니까?',
      [
        {
          text: '전체 공유',
          onPress: async () => {
            const success = await DeepLinkService.shareInviteLink(
              channel.invite_code!,
              channel.name
            );
            if (success) {
              Alert.alert('성공', '초대 링크를 공유했습니다.');
            }
          },
        },
        {
          text: '전화번호부',
          onPress: async () => {
            const success = await DeepLinkService.shareToContacts(
              channel.invite_code!,
              channel.name
            );
            if (success) {
              Alert.alert('성공', '초대 링크를 공유했습니다.');
            }
          },
        },
        {
          text: 'SMS',
          onPress: async () => {
            const success = await DeepLinkService.sendViaSMS(
              channel.invite_code!,
              channel.name
            );
            if (!success) {
              Alert.alert('오류', 'SMS 앱을 열 수 없습니다.');
            }
          },
        },
        {
          text: '취소',
          style: 'cancel',
        },
      ]
    );
  };

  const renderMemberItem = (member: ChannelMember) => (
    <View key={member.id} style={styles.memberItem}>
      <View style={styles.memberInfo}>
        <Text style={styles.memberName}>{member.nickname}</Text>
        <Text style={styles.memberEmail}>{member.email}</Text>
      </View>
      {member.role === 'admin' && (
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>관리자</Text>
        </View>
      )}
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4285F4" />
        <Text style={styles.loadingText}>불러오는 중...</Text>
      </View>
    );
  }

  if (!channel) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>채널을 찾을 수 없습니다</Text>
      </View>
    );
  }

  const isAdmin = myRole === 'admin';

  return (
    <ScrollView style={styles.container}>
      {/* 채널 정보 */}
      <View style={styles.channelInfoCard}>
        <Text style={styles.channelName}>{channel.name}</Text>
        {channel.description && (
          <Text style={styles.channelDescription}>{channel.description}</Text>
        )}
        
        {/* 초대 코드 */}
        {isAdmin && channel.invite_code && (
          <View style={styles.inviteCodeBox}>
            <Text style={styles.inviteCodeLabel}>🔑 초대 코드</Text>
            <View style={styles.inviteCodeContainer}>
              <Text style={styles.inviteCode}>{channel.invite_code}</Text>
              <TouchableOpacity
                style={styles.copyButton}
                onPress={() => {
                  // TODO: 클립보드에 복사
                  Alert.alert('복사됨', '초대 코드가 복사되었습니다.');
                }}
              >
                <Text style={styles.copyButtonText}>복사</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.inviteCodeHint}>
              이 코드를 공유하여 채널에 초대하세요
            </Text>
            
            {/* 링크 공유 버튼 */}
            <TouchableOpacity
              style={styles.shareLinkButton}
              onPress={handleShareInviteLink}
            >
              <Text style={styles.shareLinkButtonText}>📤 초대 링크 공유</Text>
            </TouchableOpacity>
          </View>
        )}
        
        <View style={styles.channelMeta}>
          <Text style={styles.metaText}>
            생성일: {new Date(channel.created_at).toLocaleDateString()}
          </Text>
          <Text style={styles.metaText}>멤버: {members.length}명</Text>
        </View>
      </View>

      {/* 알림 발송 버튼 */}
      <View style={styles.actionSection}>
        <TouchableOpacity
          style={styles.sendAlertButton}
          onPress={handleSendAlert}
        >
          <Text style={styles.sendAlertButtonText}>📢 긴급 알림 발송</Text>
        </TouchableOpacity>
      </View>

      {/* 멤버 목록 */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>멤버 ({members.length})</Text>
          {isAdmin && (
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => setShowAddMemberModal(true)}
            >
              <Text style={styles.addButtonText}>+ 추가</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.membersContainer}>
          {members.map(renderMemberItem)}
        </View>
      </View>

      {/* 채널 나가기 버튼 */}
      {!isAdmin && (
        <View style={styles.dangerSection}>
          <TouchableOpacity
            style={styles.leaveButton}
            onPress={handleLeaveChannel}
          >
            <Text style={styles.leaveButtonText}>채널 나가기</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* 멤버 추가 모달 */}
      <Modal
        visible={showAddMemberModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowAddMemberModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>멤버 추가</Text>
            <Text style={styles.modalDescription}>
              초대할 사람의 이메일을 입력하세요
            </Text>
            <TextInput
              style={styles.modalInput}
              placeholder="이메일 주소"
              value={newMemberEmail}
              onChangeText={setNewMemberEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoFocus
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalCancelButton]}
                onPress={() => setShowAddMemberModal(false)}
                disabled={addingMember}
              >
                <Text style={styles.modalCancelButtonText}>취소</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalConfirmButton]}
                onPress={handleAddMember}
                disabled={addingMember}
              >
                {addingMember ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.modalConfirmButtonText}>추가</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#999',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#999',
  },
  channelInfoCard: {
    backgroundColor: '#fff',
    padding: 20,
    marginBottom: 16,
  },
  channelName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  channelDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    marginBottom: 16,
  },
  inviteCodeBox: {
    backgroundColor: '#E3F2FD',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  inviteCodeLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#1976D2',
    marginBottom: 8,
  },
  inviteCodeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  inviteCode: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1976D2',
    letterSpacing: 4,
  },
  copyButton: {
    backgroundColor: '#1976D2',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  copyButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  inviteCodeHint: {
    fontSize: 11,
    color: '#1976D2',
  },
  shareLinkButton: {
    marginTop: 12,
    backgroundColor: '#1976D2',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  shareLinkButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  channelMeta: {
    flexDirection: 'row',
    gap: 16,
  },
  metaText: {
    fontSize: 12,
    color: '#999',
  },
  actionSection: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  sendAlertButton: {
    backgroundColor: '#FF5722',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sendAlertButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  section: {
    backgroundColor: '#fff',
    padding: 20,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  addButton: {
    backgroundColor: '#4285F4',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  membersContainer: {
    gap: 12,
  },
  memberItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  memberEmail: {
    fontSize: 14,
    color: '#999',
  },
  adminBadge: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  adminBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  dangerSection: {
    paddingHorizontal: 16,
    marginBottom: 30,
  },
  leaveButton: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#f44336',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  leaveButtonText: {
    color: '#f44336',
    fontSize: 16,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 24,
    width: '85%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  modalDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  modalInput: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 20,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCancelButton: {
    backgroundColor: '#f5f5f5',
  },
  modalCancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
  },
  modalConfirmButton: {
    backgroundColor: '#4285F4',
  },
  modalConfirmButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
});

export default ChannelDetailScreen;
