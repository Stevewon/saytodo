import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import ApiService from '../services/api';

type NavigationProp = StackNavigationProp<RootStackParamList, 'JoinChannel'>;

const JoinChannelScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const [inviteCode, setInviteCode] = useState('');
  const [loading, setLoading] = useState(false);

  const handleJoin = async () => {
    if (!inviteCode.trim()) {
      Alert.alert('입력 오류', '초대 코드를 입력해주세요.');
      return;
    }

    if (inviteCode.length !== 6) {
      Alert.alert('입력 오류', '초대 코드는 6자리입니다.');
      return;
    }

    try {
      setLoading(true);
      const response = await ApiService.joinChannelByCode(inviteCode.trim().toUpperCase());
      
      Alert.alert(
        '가입 완료',
        `"${response.channel.name}" 채널에 가입되었습니다!`,
        [
          {
            text: '확인',
            onPress: () => navigation.goBack(),
          },
        ]
      );
    } catch (error: any) {
      console.error('Join channel error:', error);
      const errorMsg = error.response?.data?.error || '채널 가입에 실패했습니다.';
      Alert.alert('오류', errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleCodeChange = (text: string) => {
    // 대문자로 변환하고 6자리까지만 입력
    const formatted = text.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
    setInviteCode(formatted);
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.content}>
        {/* 안내 */}
        <View style={styles.infoBox}>
          <Text style={styles.infoEmoji}>🔑</Text>
          <Text style={styles.infoTitle}>초대 코드로 가입하기</Text>
          <Text style={styles.infoDescription}>
            채널 관리자로부터 받은{'\n'}
            6자리 초대 코드를 입력하세요
          </Text>
        </View>

        {/* 입력 폼 */}
        <View style={styles.formContainer}>
          <Text style={styles.label}>초대 코드</Text>
          <TextInput
            style={styles.codeInput}
            placeholder="ABC123"
            value={inviteCode}
            onChangeText={handleCodeChange}
            maxLength={6}
            autoCapitalize="characters"
            autoCorrect={false}
            autoFocus
          />
          <Text style={styles.helperText}>
            6자리 대문자와 숫자 조합
          </Text>

          {/* 예시 */}
          <View style={styles.exampleBox}>
            <Text style={styles.exampleTitle}>💡 예시</Text>
            <Text style={styles.exampleText}>
              • ABC123{'\n'}
              • XYZ789{'\n'}
              • QWE456
            </Text>
          </View>
        </View>

        {/* 버튼 */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.button, styles.cancelButton]}
            onPress={() => navigation.goBack()}
            disabled={loading}
          >
            <Text style={styles.cancelButtonText}>취소</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.button,
              styles.joinButton,
              (!inviteCode || inviteCode.length !== 6) && styles.joinButtonDisabled
            ]}
            onPress={handleJoin}
            disabled={loading || !inviteCode || inviteCode.length !== 6}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.joinButtonText}>가입하기</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* 추가 안내 */}
        <View style={styles.footerInfo}>
          <Text style={styles.footerText}>
            ℹ️ 초대 코드는 채널 상세 화면에서 확인할 수 있습니다
          </Text>
          <Text style={styles.footerText}>
            ⚠️ 폐쇄형 채널이므로 검색이 불가능합니다
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  infoBox: {
    backgroundColor: '#E8F5E9',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginBottom: 30,
  },
  infoEmoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  infoTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
    marginBottom: 8,
  },
  infoDescription: {
    fontSize: 14,
    color: '#2E7D32',
    textAlign: 'center',
    lineHeight: 20,
  },
  formContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  codeInput: {
    backgroundColor: '#f9f9f9',
    borderWidth: 2,
    borderColor: '#4285F4',
    borderRadius: 8,
    padding: 16,
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    letterSpacing: 8,
  },
  helperText: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
    textAlign: 'center',
  },
  exampleBox: {
    backgroundColor: '#FFF9C4',
    borderRadius: 8,
    padding: 16,
    marginTop: 20,
  },
  exampleTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F57F17',
    marginBottom: 8,
  },
  exampleText: {
    fontSize: 13,
    color: '#F57F17',
    lineHeight: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  button: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
  },
  joinButton: {
    backgroundColor: '#4285F4',
  },
  joinButtonDisabled: {
    backgroundColor: '#ccc',
  },
  joinButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  footerInfo: {
    marginTop: 'auto',
    gap: 8,
  },
  footerText: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    lineHeight: 18,
  },
});

export default JoinChannelScreen;
