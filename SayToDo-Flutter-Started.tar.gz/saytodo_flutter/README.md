# 🚀 SayToDo Flutter

AI 기반 음성 할 일 관리 앱 (Flutter 버전)

## ✅ 구현 완료

### 화면 (3/7)
- ✅ 로그인 화면 (`lib/screens/auth/login_screen.dart`)
- ✅ 홈 화면 (`lib/screens/home/home_screen.dart`)
- ✅ 음성 녹음 화면 (`lib/screens/voice/voice_record_screen.dart`)
- ⏳ Todo 상세 화면
- ⏳ Todo 편집 화면
- ⏳ 프로필 화면
- ⏳ 설정 화면

### 기능 (5/15)
- ✅ 로그인 UI (Google 로그인 로직은 Firebase 연동 후)
- ✅ Todo 목록 표시 (임시 데이터)
- ✅ Todo 완료/미완료 토글
- ✅ Todo 삭제
- ✅ 음성 녹음 UI (STT 로직은 권한 설정 후)
- ⏳ Firebase 연동
- ⏳ 실제 음성 인식 (STT)
- ⏳ AI Todo 생성
- ⏳ Todo CRUD 완성
- ⏳ 푸시 알림

### 상태 관리
- ✅ Provider 패턴 구현
- ✅ AuthProvider
- ✅ TodoProvider

### 테마 & UI
- ✅ Light/Dark 테마
- ✅ Material Design 3
- ✅ Google Fonts (Inter)
- ✅ 반응형 디자인

## 🏗️ 프로젝트 구조

```
lib/
├── main.dart                         # 앱 진입점
├── config/
│   └── theme.dart                    # 테마 설정 ✅
├── models/
│   └── todo_model.dart               # Todo 모델 ✅
├── providers/
│   ├── auth_provider.dart            # 인증 상태 관리 ✅
│   └── todo_provider.dart            # Todo 상태 관리 ✅
├── services/                         # Firebase 서비스 (TODO)
├── screens/
│   ├── auth/
│   │   └── login_screen.dart         # 로그인 화면 ✅
│   ├── home/
│   │   └── home_screen.dart          # 홈 화면 ✅
│   ├── voice/
│   │   └── voice_record_screen.dart  # 음성 녹음 ✅
│   ├── todo/                         # Todo 상세/편집 (TODO)
│   └── profile/                      # 프로필 (TODO)
├── widgets/
│   └── todo_item.dart                # Todo 아이템 ✅
└── utils/                            # 유틸리티 (TODO)
```

## 🚀 시작하기

### 1️⃣ 의존성 설치
```bash
flutter pub get
```

### 2️⃣ 앱 실행 (웹 테스트)
```bash
flutter run -d chrome
```

### 3️⃣ APK 빌드 (나중에)
```bash
flutter build apk --release
```

## 📦 설치된 패키지

### UI/UX
- google_fonts: ^6.1.0
- flutter_svg: ^2.0.9

### 상태 관리
- provider: ^6.1.1

### Firebase (연동 예정)
- firebase_core: ^2.24.2
- firebase_auth: ^4.15.3
- cloud_firestore: ^4.13.6
- firebase_messaging: ^14.7.9

### Google 로그인
- google_sign_in: ^6.1.6

### 음성 인식
- speech_to_text: ^6.6.0
- permission_handler: ^11.1.0

### 기타
- http: ^1.1.2
- shared_preferences: ^2.2.2
- intl: ^0.18.1
- uuid: ^4.2.2
- flutter_local_notifications: ^16.3.0

## 🎯 다음 단계

### Phase 1: 기본 기능 완성 (현재)
- [x] 프로젝트 구조 생성
- [x] 로그인 화면
- [x] 홈 화면
- [x] 음성 녹음 화면
- [x] Todo 아이템 위젯
- [ ] Firebase 연동
- [ ] 실제 Google 로그인
- [ ] 실제 음성 인식

### Phase 2: 고급 기능
- [ ] Todo 상세/편집 화면
- [ ] 프로필 화면
- [ ] 설정 화면
- [ ] 푸시 알림
- [ ] 오프라인 지원
- [ ] 데이터 동기화

### Phase 3: 배포
- [ ] Android APK 빌드
- [ ] iOS IPA 빌드 (Mac 필요)
- [ ] Play Store 배포

## 🔧 현재 상태

### 작동하는 기능
✅ 앱 실행
✅ 화면 전환
✅ 임시 Todo 데이터 표시
✅ Todo 완료/미완료 토글
✅ Todo 삭제
✅ 음성 녹음 UI (시뮬레이션)

### Firebase 연동 필요
⏳ 실제 로그인
⏳ Todo CRUD (Create, Read, Update, Delete)
⏳ 데이터 동기화

### 권한 설정 필요
⏳ 마이크 권한 (음성 인식)
⏳ 알림 권한 (푸시)

## 💡 팁

### 임시 데이터 확인
현재 앱은 임시 데이터를 사용합니다:
- 로그인: 2초 대기 후 성공
- Todo: 하드코딩된 2개 항목
- 음성 인식: 3초 후 "내일 오후 3시에 회의 참석하기" 반환

### Firebase 연동 방법
```bash
# Firebase CLI 설치
npm install -g firebase-tools

# Firebase 로그인
firebase login

# Flutter 프로젝트에 Firebase 연결
flutterfire configure
```

### 음성 인식 테스트
실제 기기나 에뮬레이터가 필요합니다:
```bash
# Android 에뮬레이터
flutter run

# 실제 기기 (USB 연결)
flutter run
```

## 📱 스크린샷 (예정)

준비 중...

## 🐛 알려진 이슈

1. Firebase 미연동: 실제 로그인/데이터 저장 불가
2. 음성 인식 미구현: UI만 있고 실제 STT 없음
3. 권한 요청 없음: 마이크/알림 권한 처리 필요

## 🎉 완성도

**전체: 약 30%**
- UI/UX: 60% ✅
- 기능: 20% ⏳
- Firebase: 0% ⏳
- 테스트: 0% ⏳

## 🚀 즉시 실행하기

```bash
# 1. Flutter 설치 확인
flutter doctor

# 2. 의존성 설치
flutter pub get

# 3. 웹에서 실행 (가장 빠름!)
flutter run -d chrome

# 4. Android 에뮬레이터에서 실행
flutter run
```

---

**현재 상태**: 기본 UI 완성, Firebase 연동 대기 중

**다음**: Firebase 설정 후 실제 기능 구현

**Happy Coding!** 🎉
