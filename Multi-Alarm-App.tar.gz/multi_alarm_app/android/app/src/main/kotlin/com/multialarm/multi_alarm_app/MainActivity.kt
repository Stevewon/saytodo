package com.multialarm.multi_alarm_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
