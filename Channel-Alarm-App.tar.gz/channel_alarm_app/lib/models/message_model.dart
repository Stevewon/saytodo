import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageType {
  voice,    // 음성 메시지
  video,    // 영상
  youtube,  // 유튜브 링크
  text,     // 텍스트
}

class Message {
  final String id;
  final String channelId;
  final String senderId;
  final String senderName;
  final MessageType type;
  final String content;        // 텍스트 또는 URL
  final String? mediaUrl;      // 음성/영상 파일 URL
  final int? duration;         // 음성/영상 길이 (초)
  final String? thumbnailUrl;  // 영상 썸네일
  final DateTime createdAt;
  final List<String> readBy;   // 읽은 사람들

  Message({
    required this.id,
    required this.channelId,
    required this.senderId,
    required this.senderName,
    required this.type,
    required this.content,
    this.mediaUrl,
    this.duration,
    this.thumbnailUrl,
    required this.createdAt,
    required this.readBy,
  });

  factory Message.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Message(
      id: doc.id,
      channelId: data['channelId'] ?? '',
      senderId: data['senderId'] ?? '',
      senderName: data['senderName'] ?? '',
      type: MessageType.values.firstWhere(
        (e) => e.toString() == 'MessageType.${data['type']}',
        orElse: () => MessageType.text,
      ),
      content: data['content'] ?? '',
      mediaUrl: data['mediaUrl'],
      duration: data['duration'],
      thumbnailUrl: data['thumbnailUrl'],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      readBy: List<String>.from(data['readBy'] ?? []),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'channelId': channelId,
      'senderId': senderId,
      'senderName': senderName,
      'type': type.toString().split('.').last,
      'content': content,
      'mediaUrl': mediaUrl,
      'duration': duration,
      'thumbnailUrl': thumbnailUrl,
      'createdAt': Timestamp.fromDate(createdAt),
      'readBy': readBy,
    };
  }

  // 알림 제목 생성
  String getNotificationTitle() {
    switch (type) {
      case MessageType.voice:
        return '🎤 $senderName님이 음성 메시지를 보냈습니다';
      case MessageType.video:
        return '🎥 $senderName님이 영상을 보냈습니다';
      case MessageType.youtube:
        return '▶️ $senderName님이 유튜브 링크를 공유했습니다';
      case MessageType.text:
        return '💬 $senderName님이 메시지를 보냈습니다';
    }
  }

  // 알림 내용 생성
  String getNotificationBody() {
    switch (type) {
      case MessageType.voice:
        return '음성 메시지 ${duration ?? 0}초';
      case MessageType.video:
        return '영상 ${duration ?? 0}초';
      case MessageType.youtube:
        return content;
      case MessageType.text:
        return content;
    }
  }
}
