package com.channelalarm.channel_alarm_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
